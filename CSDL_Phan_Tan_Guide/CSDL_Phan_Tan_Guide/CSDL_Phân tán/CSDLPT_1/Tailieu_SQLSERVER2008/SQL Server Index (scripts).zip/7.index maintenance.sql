USE TEST
GO
ALTER DATABASE TEST SET AUTO_CREATE_STATISTICS OFF

TRUNCATE TABLE dbo.SalesOrderHeader
CREATE INDEX Idx_SalesOrderHeader ON dbo.SalesOrderHeader(SalesOrderID) WITH DROP_EXISTING


INSERT INTO test.dbo.SalesOrderHeader
SELECT *
FROM ADventureWorks.Sales.SalesOrderHeader

DBCC SHOW_STATISTICS (N'dbo.SalesOrderHeader', N'Idx_SalesOrderHeader')

select * from dbo.SalesOrderHeader
where SalesOrderID = 53504

UPDATE STATISTICS dbo.SalesOrderHeader Idx_SalesOrderHeader

CREATE INDEX Idx_SalesOrderHeader on dbo.SalesOrderHeader(SalesOrderID) WITH DROP_EXISTING

ALTER INDEX Idx_SalesOrderHeader on dbo.SalesOrderHeader REBUILD


delete from dbo.SalesOrderHeader


select * from sys.dm_db_index_physical_stats(db_id('test'),object_id('SalesOrderHeader'),OBJECT_ID('Idx_SalesOrderHeader'),null,null)
--where object_id = OBJECT_ID('SalesOrderHeader')

select * from sys.dm_db_index_usage_stats
where object_id = OBJECT_ID('SalesOrderHeader')

