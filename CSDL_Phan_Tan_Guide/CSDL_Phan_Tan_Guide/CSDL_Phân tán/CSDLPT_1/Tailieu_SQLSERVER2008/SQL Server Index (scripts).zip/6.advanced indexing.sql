USE test
GO
-- covering index
SELECT SalesOrderID, OrderDate, SubTotal, TaxAmt
FROM dbo.SalesOrderHeader H
WHERE H.CustomerID = 149

CREATE INDEX IX_SalesOrderHeader_CustomerID ON dbo.SalesOrderHeader(CustomerID)
INCLUDE (OrderDate, SubTotal, TaxAmt)
WITH DROP_EXISTING

--index intersection
CREATE INDEX IX_SalesOrderHeader_OrderDate ON dbo.SalesOrderHeader(OrderDate) 
CREATE INDEX IX_SalesOrderHeader_TerritoryID ON dbo.SalesOrderHeader(TerritoryID)

SELECT *
FROM dbo.SalesOrderHeader H
WHERE H.OrderDate BETWEEN '2004-03-01' AND '2004-03-31'
AND H.TerritoryID = 4


--move index to another filegroup
USE master
GO
ALTER DATABASE Test ADD FILEGROUP FG1
GO
ALTER DATABASE Test ADD FILE (NAME = N'F1', FILENAME = N'D:\DATA\test_F1.ndf') TO FILEGROUP FG1

USE TEST
GO
CREATE INDEX IX_SalesOrderHeader_CustomerID ON dbo.SalesOrderHeader(CustomerID) 
WITH DROP_EXISTING
ON FG1


SELECT *
FROM SalesOrderHeader
WHERE CustomerID BETWEEN 149 AND 160

