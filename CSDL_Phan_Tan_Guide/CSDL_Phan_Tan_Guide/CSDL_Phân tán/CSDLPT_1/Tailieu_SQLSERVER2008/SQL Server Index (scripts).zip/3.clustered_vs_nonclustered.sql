USE test
GO
SET NOCOUNT ON
ALTER DATABASE TEST SET AUTO_CREATE_STATISTICS ON
IF OBJECT_ID('dbo.Vidu_HasIndex') IS NOT NULL
	DROP TABLE dbo.Vidu_HasIndex
GO
CREATE TABLE dbo.Vidu_HasIndex(
id INT PRIMARY KEY, 
val VARCHAR(10),
val2 UNIQUEIDENTIFIER
)

DECLARE @i INT = 1
WHILE @i<=10000
BEGIN
	INSERT INTO dbo.Vidu_HasIndex
	SELECT @i, 'a'+CAST(@i AS VARCHAR), NEWID()
	SET @i = @i+1
END

CREATE INDEX idx_Vidu ON dbo.Vidu_HasIndex(val)

-- no bookmark lookup
SELECT * FROM dbo.Vidu_HasIndex
WHERE id = 190

-- bookmark lookup
SELECT * FROM dbo.Vidu_HasIndex
WHERE val = 'a190'

