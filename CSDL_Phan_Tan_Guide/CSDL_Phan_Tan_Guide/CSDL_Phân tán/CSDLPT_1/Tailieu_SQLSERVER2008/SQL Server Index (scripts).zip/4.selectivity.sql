USE test
GO
IF OBJECT_ID('SalesOrderHeader') IS NOT NULL
	DROP TABLE test.dbo.SalesOrderHeader
GO
SELECT *
INTO test.dbo.SalesOrderHeader
FROM ADventureWorks.Sales.SalesOrderHeader

ALTER TABLE test.dbo.SalesOrderHeader 
ADD CONSTRAINT PK_SalesOrderHeader PRIMARY KEY (SalesOrderID)

CREATE INDEX IX_SalesOrderHeader_OrderDate ON dbo.SalesOrderHeader(OrderDate)

-- low selectivity
SELECT *
FROM dbo.SalesOrderHeader H
WHERE H.OrderDate = '2004-03-01'


CREATE INDEX IX_SalesOrderHeader_CustomerID ON dbo.SalesOrderHeader(CustomerID)

-- high selectivity
SELECT *
FROM dbo.SalesOrderHeader H
WHERE H.CustomerID = 149

SELECT COUNT(DISTINCT OrderDate)*100.0/ COUNT(*) ord,
	COUNT(DISTINCT CustomerID)*100.0/ COUNT(*) c
FROM test.dbo.SalesOrderHeader H


-- type conversion
SELECT * FROM dbo.Vidu_HasIndex
WHERE val = N'a190'

-- function on index column
SELECT *
FROM dbo.SalesOrderHeader H
WHERE H.CustomerID + 1 = 149

-- first column must be used
DROP INDEX IX_SalesOrderHeader_OrderDate ON dbo.SalesOrderHeader
DROP INDEX IX_SalesOrderHeader_CustomerID ON dbo.SalesOrderHeader

CREATE INDEX IX_SalesOrderHeader_OrderDate_CustomerID ON dbo.SalesOrderHeader(OrderDate,CustomerID)

SELECT *
FROM dbo.SalesOrderHeader H
WHERE H.CustomerID = 149

CREATE INDEX IX_SalesOrderHeader_OrderDate_CustomerID ON dbo.SalesOrderHeader(CustomerID,OrderDate)
WITH DROP_EXISTING



