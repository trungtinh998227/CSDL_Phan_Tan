USE test
GO
SET NOCOUNT ON
/*without index*/
IF OBJECT_ID('dbo.Vidu_NoIndex') IS NOT NULL
	DROP TABLE dbo.Vidu_NoIndex
GO
SET NOCOUNT ON
CREATE TABLE dbo.Vidu_NoIndex(id INT, val VARCHAR(10))
DECLARE @i INT = 1
WHILE @i<=10000
BEGIN
	INSERT INTO dbo.Vidu_NoIndex
	SELECT @i, 'a'+CAST(@i AS VARCHAR)
	SET @i = @i+1
END

--with index
IF OBJECT_ID('dbo.Vidu_HasIndex') IS NOT NULL
	DROP TABLE dbo.Vidu_HasIndex
GO
CREATE TABLE dbo.Vidu_HasIndex(id INT, val VARCHAR(10))

INSERT INTO dbo.Vidu_HasIndex
SELECT * FROM dbo.Vidu_NoIndex

CREATE INDEX Idx_Vidu on dbo.Vidu_HasIndex(id)

SELECT *
FROM dbo.Vidu_NoIndex
WHERE id = 2184

SELECT *
FROM dbo.Vidu_HasIndex
WHERE id = 2184

/*blocking*/
--execute on the current window
BEGIN TRAN
UPDATE dbo.Vidu_NoIndex SET val = 'b'+CAST(id AS VARCHAR)
WHERE id=1

COMMIT

-- execute on a new window
BEGIN TRAN
UPDATE dbo.Vidu_NoIndex SET val = 'b'+CAST(id AS VARCHAR)
WHERE id=1000

COMMIT


--execute on the current window
BEGIN TRAN
UPDATE dbo.Vidu_HasIndex SET val = 'b'+CAST(id AS VARCHAR)
WHERE id=1

COMMIT

-- execute on a new window
BEGIN TRAN
UPDATE dbo.Vidu_HasIndex SET val = 'b'+CAST(id AS VARCHAR)
WHERE id=1000

COMMIT


--query index information
SELECT OBJECT_NAME(object_id) AS TABLE_NAME,* 
FROM sys.indexes 
--WHERE is_ms_shipped = 0
ORDER BY OBJECT_NAME(object_id)

-- drop index
DROP INDEX Idx_Vidu ON dbo.Vidu_HasIndex

--create unique constraint
ALTER TABLE dbo.Vidu_HasIndex ADD CONSTRAINT uc_id UNIQUE (ID)
