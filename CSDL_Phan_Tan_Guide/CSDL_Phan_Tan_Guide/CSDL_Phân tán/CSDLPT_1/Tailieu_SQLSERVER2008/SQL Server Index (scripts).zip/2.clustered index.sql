USE test
GO
SET NOCOUNT ON
IF OBJECT_ID('dbo.Vidu_HasIndex') IS NOT NULL
	DROP TABLE dbo.Vidu_HasIndex
GO
CREATE TABLE dbo.Vidu_HasIndex(
id INT PRIMARY KEY, 
val VARCHAR(10))

-- tao index truc tiep
CREATE CLUSTERED INDEX Idx_Vidu on dbo.Vidu_HasIndex(id)
DROP INDEX dbo.Vidu_HasIndex.Idx_Vidu 


INSERT INTO dbo.Vidu_HasIndex
SELECT * FROM dbo.Vidu_NoIndex

--query index information
SELECT OBJECT_NAME(object_id) AS TABLE_NAME,* 
FROM sys.indexes 
--WHERE is_ms_shipped = 0
ORDER BY OBJECT_NAME(object_id)

-- drop index
DROP INDEX Idx_Vidu ON dbo.Vidu_HasIndex

