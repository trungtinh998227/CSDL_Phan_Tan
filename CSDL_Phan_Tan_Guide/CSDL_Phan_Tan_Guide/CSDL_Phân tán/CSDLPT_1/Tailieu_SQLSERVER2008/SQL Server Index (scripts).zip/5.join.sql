use TEST
go
IF OBJECT_ID('SalesOrderDetail') IS NOT NULL
	DROP TABLE test.dbo.SalesOrderDetail
GO

SELECT *
INTO test.dbo.SalesOrderDetail
FROM ADventureWorks.Sales.SalesOrderDetail

SELECT *
FROM dbo.SalesOrderHeader H
JOIN dbo.SalesOrderDetail D ON H.SalesOrderID = D.SalesOrderID
WHERE H.CustomerID = 149

CREATE INDEX IX_SalesOrderDetail_SalesOrderID ON dbo.SalesOrderDetail(SalesOrderID)